/* EduPortal — sign-in Cloud Functions
 *
 * These are the two endpoints index.html's FIREBASE_FUNCTIONS_BASE points
 * at. They're the only code allowed to read a school's `users` doc (or the
 * owner password hash) before the browser has signed in to Firebase Auth —
 * the Admin SDK bypasses firestore.rules entirely, which is exactly why
 * password verification has to happen here rather than client-side once
 * real security mode is on.
 *
 * Both mirror the hashing/lookup logic already in index.html:
 *   - sha256Hex()      matches the client's sha256Hex()
 *   - schoolPrefix()   matches the client's schoolPrefix()
 *   - passwordless accounts (no passwordHash set yet) sign in on
 *     username alone, same as the existing client-side legacy path
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const crypto = require('crypto');
const cors = require('cors')({ origin: true });

admin.initializeApp();
const db = admin.firestore();
const COLLECTION = 'eduportal_kv';

function sha256Hex(str) {
  return crypto.createHash('sha256').update(str, 'utf8').digest('hex');
}

function schoolPrefix(schoolId) {
  return 'studymate_' + (schoolId || 'demo') + '_';
}

// Mirrors the client's chunked-value reassembly (see initFirebaseStorageBridge
// in index.html) so this reads exactly what the app wrote, however large.
async function readKvValue(key) {
  const doc = await db.collection(COLLECTION).doc(key).get();
  if (!doc.exists) return null;
  const data = doc.data();
  if (!data.chunked) return data.value;
  const chunkDocs = await Promise.all(
    Array.from({ length: data.chunkCount }, (_, i) =>
      db.collection(COLLECTION).doc(`${key}__chunk${i}`).get()
    )
  );
  return chunkDocs.map((d) => (d.exists ? d.data().value : '')).join('');
}

function readJson(raw, fallback) {
  if (raw == null) return fallback;
  try {
    const parsed = JSON.parse(raw);
    return parsed == null ? fallback : parsed;
  } catch (e) {
    return fallback;
  }
}

exports.mintAuthToken = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    if (req.method !== 'POST') {
      return res.status(405).json({ ok: false, error: 'Method not allowed.' });
    }
    try {
      const { schoolId, username, password } = req.body || {};
      if (!schoolId || !username) {
        return res.status(400).json({ ok: false, error: 'Missing schoolId or username.' });
      }

      const usersRaw = await readKvValue(schoolPrefix(schoolId) + 'users');
      const users = readJson(usersRaw, []);
      const user = users.find(
        (u) => (u.username || '').toUpperCase() === String(username).toUpperCase()
      );
      if (!user) {
        return res.status(200).json({ ok: false, error: 'Username not found.' });
      }

      if (user.passwordHash) {
        if (!password) {
          return res.status(200).json({ ok: false, error: 'Enter your password.' });
        }
        if (sha256Hex(password) !== user.passwordHash) {
          return res.status(200).json({ ok: false, error: 'Incorrect password.' });
        }
      }
      // else: no password set on this account yet — sign in on username alone.

      const uid = `school_${schoolId}_${user.id}`;
      const token = await admin.auth().createCustomToken(uid, {
        schoolId,
        userId: user.id,
        role: user.role || null,
      });
      return res.status(200).json({ ok: true, token, role: user.role || null });
    } catch (e) {
      console.error('mintAuthToken failed', e);
      return res.status(500).json({ ok: false, error: 'Sign-in service error.' });
    }
  });
});

exports.mintOwnerToken = functions.https.onRequest((req, res) => {
  cors(req, res, async () => {
    if (req.method !== 'POST') {
      return res.status(405).json({ ok: false, error: 'Method not allowed.' });
    }
    try {
      const { password } = req.body || {};
      if (!password) {
        return res.status(400).json({ ok: false, error: 'Missing password.' });
      }

      const storedRaw = await readKvValue('eduportal_owner_ownerPasswordHash');
      const existingHash = readJson(storedRaw, null);

      if (existingHash) {
        if (sha256Hex(password) !== existingHash) {
          return res.status(200).json({ ok: false, error: 'Incorrect password.' });
        }
      }
      // else: nobody has claimed the Owner Console yet — mint the token
      // unconditionally so the client's immediate follow-up write (setting
      // ownerPasswordHash for the first time) is allowed under firestore.rules.

      const token = await admin.auth().createCustomToken('owner', { owner: true });
      return res.status(200).json({ ok: true, token });
    } catch (e) {
      console.error('mintOwnerToken failed', e);
      return res.status(500).json({ ok: false, error: 'Sign-in service error.' });
    }
  });
});
